function [output_colorbar] = bcyr(N)

% generate "blue-cyan-yellow-red" colormap (more
% colorblind-friendly)



% generate initial "jet" colormap with N colors

% if mod(N,2) == 0
%     starting_colorbar = jet(N);
% else
%     starting_colorbar = jet(N + 1);
%     starting_colorbar = starting_colorbar(2:size(starting_colorbar,1),:);
% end

if ismember(mod(N,8),[4 5 7]) == 1
    starting_colorbar = jet(N);
elseif ismember(mod(N,8),[0 6]) == 1
    starting_colorbar = jet(N + 3);
    starting_colorbar = starting_colorbar(3:(size(starting_colorbar,1) - 1),:);
elseif mod(N,8) == 1
    starting_colorbar = jet(N + 4);
    starting_colorbar = starting_colorbar(3:(size(starting_colorbar,1) - 2),:);
elseif mod(N,8) == 2
    starting_colorbar = jet(N + 1);
    starting_colorbar = starting_colorbar(2:size(starting_colorbar,1),:);
elseif mod(N,8) == 3
    starting_colorbar = jet(N + 2);
    starting_colorbar = starting_colorbar(2:(size(starting_colorbar,1) - 1),:);
end
red = double(starting_colorbar(:,1));
green = double(starting_colorbar(:,2));
blue = double(starting_colorbar(:,3));


% scale colormap to convert from "jet" to "blue-white-red" colormap

contain_blue_ind = find(blue > 0);
red(contain_blue_ind) = min([(2*red(contain_blue_ind)) (1*ones(length(contain_blue_ind),1))],[],2);
contain_red_ind = find(red > 0);
blue(contain_red_ind) = min([(2*blue(contain_red_ind)) (1*ones(length(contain_red_ind),1))],[],2);
% blue_end_ind = find((red < 1) & (blue > 10));
blue_end_ind = find((blue - red) > 0);
green_weighting_over_red = 10.0;
sum_red_green = red(blue_end_ind) + green(blue_end_ind);
brighter_ind = find(sum_red_green > 1);
red(blue_end_ind(brighter_ind)) = 1 - ((green_weighting_over_red/(green_weighting_over_red + 1))*(2 - sum_red_green(brighter_ind)));
dimmer_ind = find(sum_red_green <= 1);
red(blue_end_ind(dimmer_ind)) = (1/(green_weighting_over_red + 1))*sum_red_green(dimmer_ind);
green(blue_end_ind) = sum_red_green - red(blue_end_ind);
% red(blue_end_ind) = min([(0.7*mean([red(blue_end_ind) green(blue_end_ind)],2)) (1*ones(length(blue_end_ind),1))],[],2);
% green(blue_end_ind) = min([(1.3*mean([red(blue_end_ind) green(blue_end_ind)],2)) (1*ones(length(blue_end_ind),1))],[],2);
% red_end_ind = find((blue < 1) & (red > 10));
red_end_ind = find((red - blue) > 0);
green_weighting_over_blue = 10.0;
sum_blue_green = blue(red_end_ind) + green(red_end_ind);
brighter_ind = find(sum_blue_green > 1);
blue(red_end_ind(brighter_ind)) = 1 - ((green_weighting_over_blue/(green_weighting_over_blue + 1))*(2 - sum_blue_green(brighter_ind)));
dimmer_ind = find(sum_blue_green <= 1);
blue(red_end_ind(dimmer_ind)) = (1/(green_weighting_over_blue + 1))*sum_blue_green(dimmer_ind);
green(red_end_ind) = sum_blue_green - blue(red_end_ind);
% green(red_end_ind) = mean([green(red_end_ind) blue(red_end_ind)],2);
% blue(red_end_ind) = mean([green(red_end_ind) blue(red_end_ind)],2);


% create new color array

output_colorbar = zeros(N,3);
output_colorbar(:,1) = red;
output_colorbar(:,2) = green;
output_colorbar(:,3) = blue;
