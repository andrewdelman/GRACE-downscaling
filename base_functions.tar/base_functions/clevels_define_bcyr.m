function [c_levels,cmap] = clevels_define(curr_array,length_cbar,end_ref_vec,range_ref_frac)

% function to define contour levels automatically based on distribution of values in curr_array
% length_cbar = number of colors in color bar
% end_ref_vec = acceptable "end" reference numbers for color bar (will be automatically scaled by appropriate power of 10)
% range_ref_frac = fraction/percentile value to use in defining the end reference values


curr_array_sorted = sort(reshape(curr_array,[numel(curr_array) 1]),1,'ascend');
curr_array_sorted = curr_array_sorted((isnan(curr_array_sorted) == 0) & (abs(curr_array_sorted) > 1e-15));
curr_array_lowrange_ref = curr_array_sorted(round(range_ref_frac*numel(curr_array_sorted)));
curr_array_highrange_ref = curr_array_sorted(round((1 - range_ref_frac)*numel(curr_array_sorted)));
curr_array_range_ref = max(abs([curr_array_lowrange_ref curr_array_highrange_ref]));
curr_array_log_ref = log(curr_array_range_ref)/log(10);
log_ref_vec = log(end_ref_vec)/log(10);
[~,closest_log_ref_ind] = min(abs(mod(log_ref_vec - curr_array_log_ref + (1/2),1) - (1/2)));
closest_exp = round(curr_array_log_ref - log_ref_vec(closest_log_ref_ind));
curr_ref = (end_ref_vec(closest_log_ref_ind))*(10^closest_exp);

c_levels = [min([(curr_array_sorted(1) - 1e-5) (-curr_ref - 1e-5)]); ((-curr_ref):(curr_ref/((length_cbar - 2)/2)):curr_ref)'; max([(curr_array_sorted(numel(curr_array_sorted)) + 1e-5) (curr_ref + 1e-5)])];
cmap = colormap(0.85*bcyr(length(c_levels) - 3));    % colormap for contours
cmap = [((2*cmap(1,:)) + ((-1)*cmap(2,:))); cmap; (((-1)*cmap(size(cmap,1) - 1,:)) + (2*cmap(size(cmap,1),:)))];
