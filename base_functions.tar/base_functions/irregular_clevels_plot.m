function [output_array,output_clabels] = irregular_clevels_plot(input_array,c_levels);

% contour plotting with irregularly spaced contours

output_array = input_array;

for n_c_level = 1:(length(c_levels) - 1)
    lower_c_level = c_levels(n_c_level);
    upper_c_level = c_levels(n_c_level + 1);
    
    in_c_level_ind = find((input_array >= lower_c_level) & (input_array < upper_c_level));
    
%     output_array(in_c_level_ind) = n_c_level - 0.5;
    output_array(in_c_level_ind) = n_c_level - 1 + ((input_array(in_c_level_ind) - lower_c_level)/(upper_c_level - lower_c_level));
    
end

% output_clabels = mat2cell(num2str(c_levels),[1 length(c_levels)]);
output_clabels = cell(length(c_levels),1);
for n_clabel = 1:length(c_levels)
    output_clabels{n_clabel} = num2str(c_levels(n_clabel));
end
