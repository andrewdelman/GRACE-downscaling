function [output_field] = interp2_fft(input_i_vec,input_j_vec,input_field,output_i,output_j)

% interpolate from 2-D grid using FFT (works best when input grid given by input_i_vec and input_j_vec has consistent spacing
% Note: (output_i, output_j) are vectors containing coordinates for individual points, NOT basis coordinates for arrays like the input vectors.  If output is desired in array format, use reshape accordingly.

warning('off','MATLAB:nearlySingularMatrix')
warning('off','MATLAB:singularMatrix')

size_input_field = size(input_field);

interp_coeffs = fft(fft(input_field,[],1)/(size(input_field,1)),[],2)/(size(input_field,2));

interp_i_ind = interp1(input_i_vec,0:1:(length(input_i_vec) - 1),reshape(output_i,[numel(output_i) 1]));
interp_j_ind = interp1(input_j_vec,0:1:(length(input_j_vec) - 1),reshape(output_j,[numel(output_j) 1]));
k_vec = (mod((0:1:(length(input_i_vec) - 1))/length(input_i_vec) + (1/2),1) - (1/2))';
l_vec = (mod((0:1:(length(input_j_vec) - 1))/length(input_j_vec) + (1/2),1) - (1/2))';


if (length(k_vec))*(length(l_vec)) >= length(interp_i_ind)
    numel_array_limit = 1e8;
    largest_array_size = prod([size_input_field length(output_i)]);
    n_subsets = ceil(largest_array_size/numel_array_limit);
    length_subset = ceil(length(output_i)/n_subsets);
    start_ind_subset = (1:length_subset:length(output_i))';
    for curr_subset = 1:length(start_ind_subset)
        curr_ind_subset = (start_ind_subset(curr_subset):1:min([(start_ind_subset(curr_subset) + length_subset) length(output_i)]))';
        G = reshape(exp(1i*(((2*pi)*repmat(repmat(reshape(k_vec,[1 length(k_vec) 1]),[length(curr_ind_subset) 1]).*repmat(interp_i_ind(curr_ind_subset),[1 length(k_vec)]),[1 1 length(l_vec)])) + ((2*pi)*repmat(repmat(reshape(l_vec,[1 1 length(l_vec)]),[length(curr_ind_subset) 1 1]).*repmat(interp_j_ind(curr_ind_subset),[1 1 length(l_vec)]),[1 length(k_vec) 1])))),[length(curr_ind_subset) (length(k_vec)*length(l_vec))]);
        if length(size_input_field) > 2
            if curr_subset == 1
                output_field = NaN([size(output_i) size_input_field(3:length(size_input_field))]);
            end
            output_ind_str = ['(curr_ind_subset,1',repmat(',:',[1 (length(size_input_field) - 2)]),')'];
            eval(['output_field',output_ind_str,' = reshape(real(G*reshape(interp_coeffs,[prod(size_input_field(1:2)) prod(size_input_field(3:length(size_input_field)))])),[length(curr_ind_subset) 1 size_input_field(3:length(size_input_field))]);'])
        else
            if curr_subset == 1
                output_field = NaN(size(output_i));
            end
            output_field(curr_ind_subset) = reshape(real(G*reshape(interp_coeffs,[numel(interp_coeffs) 1])),[length(curr_ind_subset) 1]);
        end
    end
else
    if length(size_input_field) > 2
        m = reshape(interp_coeffs,[prod(size_input_field(1:2)) size_input_field(3:(length(size_input_field)))]);
        output_field = NaN([size(output_i) size_input_field(3:length(size_input_field))]);
        for interp_i = 1:length(interp_i_ind)
            curr_i = interp_i_ind(interp_i);
            curr_j = interp_j_ind(interp_i);
            output_ind_str = ['(interp_i,1',repmat(',:',[1 (length(size_input_field) - 2)]),')'];
            eval(['output_field',output_ind_str,' = reshape(real((exp(1i*(((2*pi)*repmat(reshape(k_vec,[1 length(k_vec)])*curr_i,[1 length(l_vec)])) + ((2*pi)*reshape(repmat(reshape(l_vec,[1 length(l_vec)]),[length(k_vec) 1]),[1 ((length(k_vec))*(length(l_vec)))])*curr_j))))*m),[1 1 size_input_field(3:length(size_input_field))]);'])
        end
    else
        m = reshape(interp_coeffs,[numel(interp_coeffs) 1]);
        output_field = NaN(size(output_i));
        for interp_i = 1:length(interp_i_ind)
            curr_i = interp_i_ind(interp_i);
            curr_j = interp_j_ind(interp_i);
            output_field(interp_i) = real((exp(1i*(((2*pi)*repmat(reshape(k_vec,[1 length(k_vec)])*curr_i,[1 length(l_vec)])) + ((2*pi)*reshape(repmat(reshape(l_vec,[1 length(l_vec)]),[length(k_vec) 1]),[1 ((length(k_vec))*(length(l_vec)))])*curr_j))))*m);
        end
    end
end