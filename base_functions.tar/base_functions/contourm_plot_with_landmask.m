function [h,axm,cbar] = contourm_plot_with_landmask(fig_handle,longitude,latitude,value_array,c_levels,cmap,cbar_location,longwest,longeast,latsouth,latnorth,projection,origin)

% sets up a contour plot that has land masked out



% create first "dummy" contour plot

% lon_offset = mean(longitude([1 length(longitude)])) - mean([longwest longeast]);
if max(max(longitude)) - min(min(longitude)) > 355
    lon_offset = mean([min(min(longitude)) max(max(longitude))]) - mean([longwest longeast]);
else
    lon_offset = 0;
end
longwest_offset = longwest + lon_offset;
longeast_offset = longeast + lon_offset;


fig1000 = figure(1000);
colormap(cmap)
fig_paper_pos = get(fig1000,'PaperPosition');
fig_paper_pos(4) = ((latnorth - latsouth)/((longeast - longwest)*(cosd(mean([latsouth latnorth])))))*fig_paper_pos(3);
fig_paper_pos(3:4) = 4*fig_paper_pos(3:4);
fig_pos = get(fig1000,'Position');
fig_pos(4) = ((latnorth - latsouth)/((longeast - longwest)*(cosd(mean([latsouth latnorth])))))*fig_pos(3);
fig_pos(3:4) = 4*fig_pos(3:4);
set(fig1000,'PaperPosition',fig_paper_pos,'Position',fig_pos,'PaperSize',[44 34])
[C,g] = contourf(longitude,latitude,value_array,c_levels);
caxis([min(c_levels) max(c_levels)])
set(g,'edgecolor','none')
set(gca,'xlim',[longwest_offset longeast_offset],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
pause(20)
fig_pos = get(fig1000,'Position');
fig_pos(4) = ((latnorth - latsouth)/((longeast - longwest)*(cosd(mean([latsouth latnorth])))))*fig_pos(3);
set(fig1000,'Position',fig_pos)
print(fig1000,'contour_plot_temporary.png','-dpng','-r300')

% get(fig1000,'Position')
close(fig1000)


if longwest < -360
    lon_offset_landfind = lon_offset + (360*(floor((longwest - (-360))/360)));
elseif longeast > 360
    lon_offset_landfind = lon_offset - (360*(ceil((longeast - 360)/360)));
end
longwest_offset = longwest + lon_offset_landfind;
longeast_offset = longeast + lon_offset_landfind;


% get contour plot and overlay land mask

rgb_array = imread('contour_plot_temporary.png');
rgb_array = flip(permute(rgb_array,[2 1 3]),2);

delete('contour_plot_temporary.png')


size_rgb_array = size(rgb_array);
frac_first_part = (min([longeast_offset 0]) - max([(-360) longwest_offset]))/(min([longeast_offset 360]) - max([(-360) longwest_offset]));
if frac_first_part <= 0
    landmask_ind = landfind_indices(longwest_offset,longeast_offset,latsouth,latnorth,size_rgb_array(1:2));
elseif frac_first_part >= 1
    landmask_ind = landfind_indices(longwest_offset + 360,longeast_offset + 360,latsouth,latnorth,size_rgb_array(1:2));
else
    landmask_i_ind = [(mod(landfind_indices(longwest_offset + 360,(longwest_offset*(1 - (floor(frac_first_part*(size_rgb_array(1)))/(frac_first_part*(size_rgb_array(1)))))) + 360,latsouth,latnorth,floor([frac_first_part 1].*(size_rgb_array(1:2)))) - 1,floor(frac_first_part*(size_rgb_array(1)))) + 1); (mod(landfind_indices(longwest_offset*(1 - (floor(frac_first_part*(size_rgb_array(1)))/(frac_first_part*(size_rgb_array(1))))),longeast_offset,latsouth,latnorth,size_rgb_array(1:2) - floor([frac_first_part 0].*(size_rgb_array(1:2)))) - 1,size_rgb_array(1) - floor(frac_first_part*(size_rgb_array(1)))) + 1 + (floor(frac_first_part*(size_rgb_array(1)))))];
    landmask_j_ind = [(ceil(landfind_indices(longwest_offset + 360,(longwest_offset*(1 - (floor(frac_first_part*(size_rgb_array(1)))/(frac_first_part*(size_rgb_array(1)))))) + 360,latsouth,latnorth,floor([frac_first_part 1].*(size_rgb_array(1:2))))/(floor(frac_first_part*(size_rgb_array(1)))))); (ceil(landfind_indices(longwest_offset*(1 - (floor(frac_first_part*(size_rgb_array(1)))/(frac_first_part*(size_rgb_array(1))))),longeast_offset,latsouth,latnorth,size_rgb_array(1:2) - floor([frac_first_part 0].*(size_rgb_array(1:2))))/(size_rgb_array(1) - floor(frac_first_part*(size_rgb_array(1))))))];
    landmask_ind = double(landmask_i_ind) + ((size_rgb_array(1))*(double(landmask_j_ind) - 1));
end
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);

% put black mask on land areas
rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);

rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


% plot contour map with land mask

fig_handle;
axm = axesm(projection,'origin',origin);
% R = georefcells([latsouth latnorth],[longwest longeast],(size_rgb_array(1:2))');
h = geoshow(repmat((latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)',[1 size(rgb_array,1)]),repmat(longwest_offset:((longeast_offset - longwest_offset)/(size(rgb_array,1) - 1)):longeast_offset,[size(rgb_array,2) 1]),permute(rgb_array_masked,[2 1 3]));

% plot color bar
colormap(cmap)
cbar = colorbar('location',cbar_location);
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
        if mod(n_label,2) == 1
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)