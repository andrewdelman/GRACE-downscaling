function [correlation_array_at_lags,correlation_dof_array_zero_lag,integral_scale_1,integral_scale_2,correlation_array_low_mag_bound,correlation_array_high_mag_bound,lags] = correlation_scalar_scalar_uncert_bounds(input_array_1,input_array_2,n_dim,delta_dim,delta_lag,lag_range_to_test,confidence_level)


dim_length = size(input_array_1,n_dim);

size_array = size(input_array_1);
prod_size_not_inc_corr_dim = prod(size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]));

input_array_1_permuted = reshape(permute(input_array_1,[n_dim (1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]),[dim_length prod_size_not_inc_corr_dim]);
input_array_2_permuted = reshape(permute(input_array_2,[n_dim (1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]),[dim_length prod_size_not_inc_corr_dim]);

nan_mask_input_1 = ones(size(input_array_1_permuted));
nan_mask_input_1(union(union(find(isnan(input_array_1_permuted) == 1),find(isinf(input_array_1_permuted) == 1)),find(abs(input_array_1_permuted) < (1e-15)*max(max(abs(input_array_1_permuted)))))) = 0;
nan_mask_input_2 = ones(size(input_array_2_permuted));
nan_mask_input_2(union(union(find(isnan(input_array_2_permuted) == 1),find(isinf(input_array_2_permuted) == 1)),find(abs(input_array_2_permuted) < (1e-15)*max(max(abs(input_array_2_permuted)))))) = 0;
% nan_mask_input = nan_mask_input_1 & nan_mask_input_2;


input_array_1_zeronans = input_array_1_permuted;
input_array_1_zeronans(abs(nan_mask_input_1) < 1e-5) = 0;
input_array_1_zeronans = input_array_1_zeronans - repmat(sum(nan_mask_input_1.*input_array_1_zeronans,1)./sum(nan_mask_input_1,1),[dim_length 1]);
input_array_2_zeronans = input_array_2_permuted;
input_array_2_zeronans(abs(nan_mask_input_2) < 1e-5) = 0;
input_array_2_zeronans = input_array_2_zeronans - repmat(sum(nan_mask_input_2.*input_array_2_zeronans,1)./sum(nan_mask_input_2,1),[dim_length 1]);

% remove means and trends
index_array_nomean = repmat((1:1:size(input_array_1_zeronans,1))',[1 prod_size_not_inc_corr_dim]) - repmat((sum(nan_mask_input_1.*repmat((1:1:size(input_array_1_zeronans,1))',[1 prod_size_not_inc_corr_dim]),1)./sum(nan_mask_input_1,1)),[size(input_array_1_zeronans,1) 1]);
input_array_1_zeronans_nomean = input_array_1_zeronans - repmat((sum(nan_mask_input_1.*input_array_1_zeronans,1)./sum(nan_mask_input_1,1)),[size(input_array_1_zeronans,1) 1]);
input_array_1_zeronans = input_array_1_zeronans_nomean - (index_array_nomean.*repmat((1./sum((nan_mask_input_1.*index_array_nomean).^2,1)).*sum(nan_mask_input_1.*index_array_nomean.*input_array_1_zeronans_nomean,1),[size(input_array_1_zeronans,1) 1]));
index_array_nomean = repmat((1:1:size(input_array_2_zeronans,1))',[1 prod_size_not_inc_corr_dim]) - repmat((sum(nan_mask_input_2.*repmat((1:1:size(input_array_2_zeronans,1))',[1 prod_size_not_inc_corr_dim]),1)./sum(nan_mask_input_2,1)),[size(input_array_2_zeronans,1) 1]);
input_array_2_zeronans_nomean = input_array_2_zeronans - repmat((sum(nan_mask_input_2.*input_array_2_zeronans,1)./sum(nan_mask_input_2,1)),[size(input_array_2_zeronans,1) 1]);
input_array_2_zeronans = input_array_2_zeronans_nomean - (index_array_nomean.*repmat((1./sum((nan_mask_input_2.*index_array_nomean).^2,1)).*sum(nan_mask_input_2.*index_array_nomean.*input_array_2_zeronans_nomean,1),[size(input_array_2_zeronans,1) 1]));


% compute degrees of freedom

delta_lag_ind = round(delta_lag/delta_dim);
lags = round((delta_lag*(ceil(lag_range_to_test(1)/delta_lag):1:floor(lag_range_to_test(2)/delta_lag))')/delta_dim)*delta_dim;

autocorr_lags = ((delta_dim*delta_lag_ind):(delta_dim*delta_lag_ind):max(abs(lags)))';
N = length(autocorr_lags);


lag_step = delta_lag_ind;    % number of time points between lags to test for dof

input_1_autocorr_at_lags = NaN([N prod_size_not_inc_corr_dim]);
input_2_autocorr_at_lags = NaN([N prod_size_not_inc_corr_dim]);
input_1_integral_scale = NaN([1 prod_size_not_inc_corr_dim]);
input_2_integral_scale = NaN([1 prod_size_not_inc_corr_dim]);
n_lag_step = 1;
lag_ind = lag_step;
complete_flag = 0;
while ((complete_flag == 0) && (n_lag_step <= N))

    part_1_ind = (1:1:(dim_length - lag_ind))';
    part_2_ind = ((1 + lag_ind):1:dim_length)';
    nan_mask_combined = nan_mask_input_1(part_1_ind,:) & nan_mask_input_1(part_2_ind,:);
    part_1_mean = sum(nan_mask_combined.*input_array_1_zeronans(part_1_ind,:),1)./sum(nan_mask_combined,1);
    part_2_mean = sum(nan_mask_combined.*input_array_1_zeronans(part_2_ind,:),1)./sum(nan_mask_combined,1);
    input_1_autocorr_at_lags(n_lag_step,:) = sum(nan_mask_combined.*(input_array_1_zeronans(part_1_ind,:) - repmat(part_1_mean,[length(part_1_ind) 1])).*(input_array_1_zeronans(part_2_ind,:) - repmat(part_2_mean,[length(part_2_ind) 1])),1)./(((sum(nan_mask_combined.*((input_array_1_zeronans(part_1_ind,:) - repmat(part_1_mean,[length(part_1_ind) 1])).^2),1)).^(1/2)).*((sum(nan_mask_combined.*((input_array_1_zeronans(part_2_ind,:) - repmat(part_2_mean,[length(part_2_ind) 1])).^2),1)).^(1/2)));
    
    nan_mask_combined = nan_mask_input_2(part_1_ind,:) & nan_mask_input_2(part_2_ind,:);
    part_1_mean = sum(nan_mask_combined.*input_array_2_zeronans(part_1_ind,:),1)./sum(nan_mask_combined,1);
    part_2_mean = sum(nan_mask_combined.*input_array_2_zeronans(part_2_ind,:),1)./sum(nan_mask_combined,1);
    input_2_autocorr_at_lags(n_lag_step,:) = sum(nan_mask_combined.*(input_array_2_zeronans(part_1_ind,:) - repmat(part_1_mean,[length(part_1_ind) 1])).*(input_array_2_zeronans(part_2_ind,:) - repmat(part_2_mean,[length(part_2_ind) 1])),1)./(((sum(nan_mask_combined.*((input_array_2_zeronans(part_1_ind,:) - repmat(part_1_mean,[length(part_1_ind) 1])).^2),1)).^(1/2)).*((sum(nan_mask_combined.*((input_array_2_zeronans(part_2_ind,:) - repmat(part_2_mean,[length(part_2_ind) 1])).^2),1)).^(1/2)));
    
    if n_lag_step == N
        first_neg_ind_1 = find((isnan(input_1_integral_scale) == 1) & (isnan(input_1_autocorr_at_lags(1,:)) == 0));
        first_neg_ind_2 = find((isnan(input_2_integral_scale) == 1) & (isnan(input_2_autocorr_at_lags(1,:)) == 0));
    else
        first_neg_ind_1 = find(((input_1_autocorr_at_lags(n_lag_step,:) < 0) | ((isnan(input_1_autocorr_at_lags(n_lag_step,:)) == 1) & (isnan(input_1_autocorr_at_lags(1,:)) == 0))) & (isnan(input_1_integral_scale) == 1));
        first_neg_ind_2 = find(((input_2_autocorr_at_lags(n_lag_step,:) < 0) | ((isnan(input_2_autocorr_at_lags(n_lag_step,:)) == 1) & (isnan(input_2_autocorr_at_lags(1,:)) == 0))) & (isnan(input_2_integral_scale) == 1));
    end
    
    first_neg_ind_mask_2D = zeros([1 prod_size_not_inc_corr_dim]);
    first_neg_ind_mask_2D(first_neg_ind_1) = 1;
    first_neg_ind_mask = repmat(first_neg_ind_mask_2D,[n_lag_step 1]);
    first_neg_ind_mask(n_lag_step,:) = 0.5*first_neg_ind_mask(n_lag_step,:);
    input_1_autocorr_at_lags_zeronans = input_1_autocorr_at_lags;
    input_1_autocorr_at_lags_zeronans(isnan(input_1_autocorr_at_lags) == 1) = 0;
    curr_input_1_integral_scale = delta_dim*lag_step*(ceil(first_neg_ind_mask(1,:)) + max([zeros([1 prod_size_not_inc_corr_dim]); (2*sum(first_neg_ind_mask.*input_1_autocorr_at_lags_zeronans(1:n_lag_step,:),1))],[],1));
    clear input_1_autocorr_at_lags_zeronans
    if n_lag_step > 1
        nan_case_integral_scale = min([repmat((delta_dim*lag_ind),[1 prod_size_not_inc_corr_dim]); (delta_dim*lag_step*(first_neg_ind_mask(1,:) + (2*sum((first_neg_ind_mask(1:(n_lag_step - 1),:)).*input_1_autocorr_at_lags(1:(n_lag_step - 1),:),1))))],[],1);
        curr_input_1_integral_scale(first_neg_ind_1(isnan(curr_input_1_integral_scale(first_neg_ind_1)) == 1)) = nan_case_integral_scale(first_neg_ind_1(isnan(curr_input_1_integral_scale(first_neg_ind_1)) == 1));
    end
    input_1_integral_scale(first_neg_ind_1) = curr_input_1_integral_scale(first_neg_ind_1);

    first_neg_ind_mask_2D = zeros([1 prod_size_not_inc_corr_dim]);
    first_neg_ind_mask_2D(first_neg_ind_2) = 1;
    first_neg_ind_mask = repmat(first_neg_ind_mask_2D,[n_lag_step 1]);
    first_neg_ind_mask(n_lag_step,:) = 0.5*first_neg_ind_mask(n_lag_step,:);
    input_2_autocorr_at_lags_zeronans = input_2_autocorr_at_lags;
    input_2_autocorr_at_lags_zeronans(isnan(input_2_autocorr_at_lags) == 1) = 0;
    curr_input_2_integral_scale = delta_dim*lag_step*(ceil(first_neg_ind_mask(1,:)) + max([zeros([1 prod_size_not_inc_corr_dim]); (2*sum(first_neg_ind_mask.*input_2_autocorr_at_lags_zeronans(1:n_lag_step,:),1))],[],1));
    clear input_2_autocorr_at_lags_zeronans
    if n_lag_step > 1
        nan_case_integral_scale = min([repmat((delta_dim*lag_ind),[1 prod_size_not_inc_corr_dim]); (delta_dim*lag_step*(first_neg_ind_mask(1,:) + (2*sum((first_neg_ind_mask(1:(n_lag_step - 1),:)).*input_2_autocorr_at_lags(1:(n_lag_step - 1),:),1))))],[],1);
        curr_input_2_integral_scale(first_neg_ind_2(isnan(curr_input_2_integral_scale(first_neg_ind_2)) == 1)) = nan_case_integral_scale(first_neg_ind_2(isnan(curr_input_2_integral_scale(first_neg_ind_2)) == 1));
    end
    input_2_integral_scale(first_neg_ind_2) = curr_input_2_integral_scale(first_neg_ind_2);
    
    if ((sum(sum(isnan(input_1_integral_scale))) == 0) && (sum(sum(isnan(input_2_integral_scale))) == 0))
        complete_flag = 1;
    end
    
%     disp(['lag_ind = ',num2str(lag_ind),' (out of ',num2str(N*lag_step),')'])
    
    n_lag_step = n_lag_step + 1;
    lag_ind = lag_ind + lag_step;

end

input_corr_integral_scale = min([input_1_integral_scale; input_2_integral_scale],[],1);
corr_dof_array = (delta_dim*sum((nan_mask_input_1 & nan_mask_input_2),1))./input_corr_integral_scale;

integral_scale_1 = permute(reshape(input_1_integral_scale,[1 size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);
integral_scale_2 = permute(reshape(input_2_integral_scale,[1 size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);
correlation_dof_array_zero_lag = permute(reshape(corr_dof_array,[1 size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);

% compute pointwise correlations

corrcoeff_array = NaN([length(lags) prod_size_not_inc_corr_dim]);
corrcoeff_low_mag = NaN([length(lags) prod_size_not_inc_corr_dim]);
corrcoeff_high_mag = NaN([length(lags) prod_size_not_inc_corr_dim]);
for n_lag_ind = 1:length(lags)
    curr_lag = lags(n_lag_ind);
    lag_ind = round(curr_lag/delta_dim);
    input_1_corr_ind = (max([1 (1 - lag_ind)]):min([dim_length (dim_length - lag_ind)]))';
    input_2_corr_ind = (max([1 (1 + lag_ind)]):min([dim_length (dim_length + lag_ind)]))';
    
    nan_mask_combined = nan_mask_input_1(input_1_corr_ind,:) & nan_mask_input_2(input_2_corr_ind,:);
    part_1_mean = sum(nan_mask_combined.*input_array_1_zeronans(input_1_corr_ind,:),1)./sum(nan_mask_combined,1);
    part_2_mean = sum(nan_mask_combined.*input_array_2_zeronans(input_2_corr_ind,:),1)./sum(nan_mask_combined,1);
    corrcoeff_array(n_lag_ind,:) = sum(nan_mask_combined.*(input_array_1_zeronans(input_1_corr_ind,:) - repmat(part_1_mean,[length(input_1_corr_ind) 1])).*(input_array_2_zeronans(input_2_corr_ind,:) - repmat(part_2_mean,[length(input_2_corr_ind) 1])),1)./(((sum(nan_mask_combined.*((input_array_1_zeronans(input_1_corr_ind,:) - repmat(part_1_mean,[length(input_1_corr_ind) 1])).^2),1)).^(1/2)).*((sum(nan_mask_combined.*((input_array_2_zeronans(input_2_corr_ind,:) - repmat(part_2_mean,[length(input_2_corr_ind) 1])).^2),1)).^(1/2)));
    
    curr_corr_dof_array = (delta_dim*sum(nan_mask_combined,1))./input_corr_integral_scale;
    
    stderror_Z = (curr_corr_dof_array - 3).^(-1/2);

    stderror_Z(curr_corr_dof_array < 3) = Inf;

    normalized_Z_value = 0.5*(log(1 + abs(corrcoeff_array(n_lag_ind,:))) - log(1 - abs(corrcoeff_array(n_lag_ind,:))));
    Z_confidence_lower_mag = normalized_Z_value - (stderror_Z*(erfinv(confidence_level))*(2^(1/2)));
    r_confidence_lower_mag = 1 - (2./(exp(2*Z_confidence_lower_mag) + 1));
    Z_confidence_higher_mag = normalized_Z_value + (stderror_Z*(erfinv(confidence_level))*(2^(1/2)));
    r_confidence_higher_mag = 1 - (2./(exp(2*Z_confidence_higher_mag) + 1));
    
    corrcoeff_low_mag(n_lag_ind,:) = (sign(corrcoeff_array(n_lag_ind,:))).*r_confidence_lower_mag;
    corrcoeff_high_mag(n_lag_ind,:) = (sign(corrcoeff_array(n_lag_ind,:))).*r_confidence_higher_mag;
end


correlation_array_at_lags = permute(reshape(corrcoeff_array,[length(lags) size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);
correlation_array_low_mag_bound = permute(reshape(corrcoeff_low_mag,[length(lags) size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);
correlation_array_high_mag_bound = permute(reshape(corrcoeff_high_mag,[length(lags) size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))])]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array))]);