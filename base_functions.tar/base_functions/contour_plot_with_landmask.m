function [h,cbar] = contour_plot_with_landmask(fig_handle,longitude,latitude,value_array,c_levels,cmap,cbar_location,longwest,longeast,latsouth,latnorth)

% sets up a contour plot that has land masked out


% adjust for continuity of longitude values
if longeast <= longwest
    longeast = longeast + (360*(floor((longwest - longeast)/360) + 1));
end


% create first "dummy" contour plot

fig1000 = figure(1000);
colormap(cmap)
fig_paper_pos = get(fig1000,'PaperPosition');
fig_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig_paper_pos(3);
fig_paper_pos(3:4) = 2*fig_paper_pos(3:4);
set(fig1000,'PaperPosition',fig_paper_pos,'PaperSize',[22 17])
[C,g] = contourf(longitude,latitude,value_array,c_levels);
caxis([min(c_levels) max(c_levels)])
set(g,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
pause(5)
plotboxaspectratio = get(gca,'PlotBoxAspectRatio');
fig_pos = get(gcf,'Position');
ratio_plotbox = plotboxaspectratio(2)/plotboxaspectratio(1);
ratio_fig = fig_pos(4)/fig_pos(3);
if ratio_fig > ratio_plotbox
    fig_pos(4) = ratio_plotbox*fig_pos(3);
else
    fig_pos(3) = fig_pos(4)/ratio_plotbox;
end
set(gcf,'Position',fig_pos)

print(gcf,'contour_plot_temporary.png','-dpng','-r300')
close(fig1000)



% get contour plot and overlay land mask

rgb_array = imread('contour_plot_temporary.png');
rgb_array = flip(permute(rgb_array,[2 1 3]),2);

delete('contour_plot_temporary.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);

% put black mask on land areas
rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);

rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


% plot contour map with land mask

fig_handle;
h = image(longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast,(latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)',permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])

% plot color bar
colormap(cmap)
cbar = colorbar('location',cbar_location);
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
        if mod(n_label,2) == 1
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)
