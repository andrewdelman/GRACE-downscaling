function [STD,RMS,CORR] = taylor_stats_txy(ref,tf,w,norma)

% [STD,RMS,CORR] = taylor_stats_txy(reference_field,test_field,weights,norma)
% REF and TF    data(time,X)
% W             data weights W(X)
% NORMA:        1 = normalized to REF; 0 (default) = absolute
%
% weights: fraction of total (non-zero) area, such that sum(weights) = 1!
% assumes constant spacing in time! (i.e.: time weights are all the same!)
% centered RMS: (1) time-means of 'TF' and 'REF' will be subtracted (at each grid point)!
%               (2) spatial-mean of time-mean will be subtracted!    
%
% felix.w.landerer@jpl.nasa.gov [last modified: Nov-17, 2014]

defval('norma',0);
defval('w',ones(size(ref,2),size(ref,3)));

if ndims(ref) ~= ndims(tf)
    disp('Input fields REF and TF must have same dimensions!');
    return
elseif ndims(ref) == 3
    disp('collapsing dimensions of input fields to (time,space)');
    ref = ref(:,:);
    tf = tf(:,:);
elseif ndims(ref) <=1 || ndims(ref) > 3
    disp('check dimensions of input fields!')
end

w = w(:);
I = find(w); %only use non-zero-weight pixels

reft = zeros(size(ref,1),size(I,1));
tft = reft;
wt = reft;

% 
for t=1:size(ref,1);
    reft(t,:) = ref(t,I);
    tft(t,:) = tf(t,I);
    wt(t,:) = w(I);
end

% subtract time-mean at each data grid-point:
% NOTE:  - only do this if # of time samples > 1!
%        - if nt=1, proceed with removing spatial mean only
%          (i.e., compute stats for time-invariant field)
if size(tft,1) > 1
tft = tft - repmat(mean(tft,1),[size(tft,1),1]);
reft = reft - repmat(mean(reft,1),[size(reft,1),1]);
end

% subtract weighted spatial-mean from all data grid-points:
% NOTE:  - this step can be redundant in some configs, but do nonetheless
%          to make script work for all cases
tft = tft - mean(tft,1) * wt(1,:)';
reft = reft - mean(reft,1) * wt(1,:)';

% make one long data vector:
tft = tft(:);
reft = reft(:);
wt = wt(:);

ref_std = sqrt(1/sum(wt) * sum(reft.^2 .* wt));

STD = sqrt(1/sum(wt) * sum(tft.^2 .* wt));
RMS = sqrt(1/sum(wt) * sum((tft-reft).^2 .* wt));
CORR = 1/sum(wt) * sum(reft .* tft .* wt) / (ref_std * STD);

if norma
    STD = STD / ref_std;
    RMS = RMS / ref_std;
end

return
