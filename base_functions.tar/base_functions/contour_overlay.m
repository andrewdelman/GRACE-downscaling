function [] = contour_overlay(x_array,y_array,z_array,contour_values,line_color,line_style,line_width)

contour_matrix = contourc(x_array,y_array,z_array,contour_values);
pt_ind = 1;
while pt_ind <= size(contour_matrix,2)
    n_pairs_inseg = contour_matrix(2,pt_ind);
%     x_pts_inseg = interp1((1:1:size(x_array,2)),x_array,contour_matrix(1,(pt_ind + 1):(pt_ind + n_pairs_inseg)));
%     y_pts_inseg = interp1((1:1:size(y_array,1)),y_array,contour_matrix(2,(pt_ind + 1):(pt_ind + n_pairs_inseg)));
    x_pts_inseg = contour_matrix(1,(pt_ind + 1):(pt_ind + n_pairs_inseg));
    y_pts_inseg = contour_matrix(2,(pt_ind + 1):(pt_ind + n_pairs_inseg));
    line(x_pts_inseg,y_pts_inseg,ones(1,n_pairs_inseg),'Color',line_color,'LineStyle',line_style,'LineWidth',line_width)
    
    pt_ind = pt_ind + n_pairs_inseg + 1;
end
