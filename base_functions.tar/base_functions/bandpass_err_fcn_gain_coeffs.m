function [bandpass_gain_coeff_array] = bandpass_err_fcn_gain_coeffs(input_array,n_dim,delta_dim,low_bound,high_bound,steepness_factor,mean_handling_opt,uneven_edge_handling_opt)

% delta_dim: spacing of grid in dimension of bandpassing
% low_bound: low frequency-wavenumber bound
% high_bound: high frequency-wavenumber bound
% n_dim: number of dimension to bandpass along
% steepness_factor: how rapidly the bandpass filter cuts off at the
% boundaries (must be positive; higher values have a steeper cutoff, and
% possibly more spectral ringing)
% mean_handling_opt: 0 = gain coefficients do not include mean; 1 = gain coeffients include mean (trend is not removed in this function regardless)
% uneven_edge_handling_opt: 0 = treat edges as even, with zeros for NaNs;
% 1 = adjust padding positions for uneven edges

dim_length = size(input_array,n_dim);

f_vec = (1/(delta_dim*(2*dim_length)))*(mod((0:1:((2*dim_length) - 1))' + dim_length,(2*dim_length)) - dim_length);

% n_avg_ind = round(((1/8)*exp(-mean(log([low_bound high_bound]))))/delta_dim);  
n_avg_ind = round(((1/8)*exp(-mean(log([max([low_bound (1/(delta_dim*dim_length))]) min([high_bound (1/(2*delta_dim))])]))))/delta_dim);  

% bandpass_filter = 2*0.5*(erf(steepness_factor*(log(abs(f_vec)) - log(low_bound))) - erf(steepness_factor*(log(abs(f_vec)) - log(high_bound))));
bandpass_filter = 0.5*(erf(steepness_factor*(log(abs(f_vec)) - log(low_bound))) - erf(steepness_factor*(log(abs(f_vec)) - log(high_bound))));
if abs(mean_handling_opt - 1) < 1e-5
    bandpass_filter(1) = 1;
end

% G = [ones(dim_length,1) (1:1:dim_length)'];
% reg_operator_trend = G*(((G')*G)^(-1))*(G');
padding_ind_inside = floor(dim_length/2) + (1:1:dim_length)';
if abs(uneven_edge_handling_opt) < 1e-5
    padding_ind_begin = (1:1:floor(dim_length/2))';
    padding_ind_end = ((floor(dim_length/2) + dim_length + 1):1:(2*dim_length))';
end

size_array = size(input_array);
prod_size_not_inc_bp_dim = prod(size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]));


input_array_permuted = reshape(permute(input_array,[n_dim (1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]),[dim_length prod_size_not_inc_bp_dim]);
nan_ind_permuted = union(union(find(isnan(input_array_permuted) == 1),find(isinf(input_array_permuted) == 1)),find(abs(input_array_permuted) < (1e-15)*max(abs(input_array_permuted(isinf(input_array_permuted) == 0)))));
clear input_array
input_array_permuted(nan_ind_permuted) = 0;
nan_mask_input_permuted = ones(size(input_array_permuted));
nan_mask_input_permuted(nan_ind_permuted) = 0;
% % trend_array_permuted = reshape(reg_operator_trend*(reshape(input_array_permuted,[dim_length prod_size_not_inc_bp_dim])),size_array([n_dim (1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]));
% 
% % remove means and trends
% index_array_nomean = repmat((1:1:size(input_array_permuted,1))',[1 prod_size_not_inc_bp_dim]) - repmat((sum(nan_mask_input_permuted.*repmat((1:1:size(input_array_permuted,1))',[1 prod_size_not_inc_bp_dim]),1)./sum(nan_mask_input_permuted,1)),[size(input_array_permuted,1) 1]);
% input_array_permuted_nomean = input_array_permuted - repmat((sum(nan_mask_input_permuted.*input_array_permuted,1)./sum(nan_mask_input_permuted,1)),[size(input_array_permuted,1) 1]);
% trend_array_permuted = (index_array_nomean.*repmat((1./sum((nan_mask_input_permuted.*index_array_nomean).^2,1)).*sum(nan_mask_input_permuted.*index_array_nomean.*input_array_permuted_nomean,1),[size(input_array_permuted,1) 1]));
% trend_array_permuted = trend_array_permuted + (input_array_permuted - input_array_permuted_nomean);
% 
% input_array_permuted_minus_trend = input_array_permuted - trend_array_permuted;
% clear input_array_permuted
% 
% input_array_permuted_minus_trend(nan_ind_permuted) = 0;
% 
% 
% % input_array_variance = sum(nan_mask_input_permuted.*(input_array_permuted_minus_trend.^2),1)./sum(nan_mask_input_permuted,1);


bandpass_gain_coeff_permuted = NaN([dim_length prod_size_not_inc_bp_dim dim_length]);
for curr_ind = 1:dim_length
    curr_input_padded = zeros([(2*dim_length) prod_size_not_inc_bp_dim]);
    curr_input_padded(padding_ind_inside(1) - 1 + curr_ind,:) = 1;

    % pad with erf slopes on either end of the range
    if abs(uneven_edge_handling_opt - 1) < 1e-5
        first_good_ind = ones([1 prod_size_not_inc_bp_dim]);
        last_good_ind = dim_length*ones([1 prod_size_not_inc_bp_dim]);
        cum_forward_nan_mask_input_permuted = cumsum(nan_mask_input_permuted,1);
        cum_reverse_nan_mask_input_permuted = flipdim(cumsum(flipdim(nan_mask_input_permuted,1)),1);
        first_good_ind(abs(cum_forward_nan_mask_input_permuted(dim_length,:)) > 1e-5) = (mod(union(find((abs(repmat((1:1:dim_length)',[1 prod_size_not_inc_bp_dim]) - 1) < 1e-5) & (abs(cum_forward_nan_mask_input_permuted - 1) < 1e-5)),find((abs([((-1)*ones([1 prod_size_not_inc_bp_dim])); cum_forward_nan_mask_input_permuted(1:(dim_length - 1),:)]) < 1e-5) & (abs([((-1)*ones([1 prod_size_not_inc_bp_dim])); cum_forward_nan_mask_input_permuted(2:dim_length,:)] - 1) < 1e-5))) - 1,dim_length) + 1)';
        last_good_ind(abs(cum_reverse_nan_mask_input_permuted(1,:)) > 1e-5) = (mod(union(find((abs(repmat((1:1:dim_length)',[1 prod_size_not_inc_bp_dim]) - dim_length) < 1e-5) & (abs(cum_reverse_nan_mask_input_permuted - 1) < 1e-5)),find((abs([cum_reverse_nan_mask_input_permuted(2:dim_length,:); ((-1)*ones([1 prod_size_not_inc_bp_dim]))]) < 1e-5) & (abs([cum_reverse_nan_mask_input_permuted(1:(dim_length - 1),:); ((-1)*ones([1 prod_size_not_inc_bp_dim]))] - 1) < 1e-5))) - 1,dim_length) + 1)';
    end
    if n_avg_ind > 0
        if abs(uneven_edge_handling_opt) < 1e-5
            pad_slope_begin = (mean(curr_input_padded(floor(dim_length/2) + ((n_avg_ind + 1):(2*n_avg_ind)),:),1) - mean(curr_input_padded(floor(dim_length/2) + (1:n_avg_ind),:),1))/n_avg_ind;
            pad_val_begin = mean(curr_input_padded(floor(dim_length/2) + (1:n_avg_ind),:),1) - (((n_avg_ind - 1)/2)*pad_slope_begin);
            pad_slope_end = (mean(curr_input_padded(floor(dim_length/2) + ((dim_length - n_avg_ind + 1):dim_length),:),1) - mean(curr_input_padded(floor(dim_length/2) + ((dim_length - (2*n_avg_ind) + 1):(dim_length - n_avg_ind)),:),1))/n_avg_ind;
            pad_val_end = mean(curr_input_padded(floor(dim_length/2) + ((dim_length - n_avg_ind + 1):dim_length),:),1) + (((n_avg_ind - 1)/2)*pad_slope_end);
        else
            along_dim_ind_array = repmat((1:1:(2*dim_length))',[1 prod_size_not_inc_bp_dim]);
            avg_range_mask_1 = zeros(size(curr_input_padded));
            avg_range_mask_1((along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) + 1 >= 1) & (along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) + 1 <= n_avg_ind)) = 1;
            avg_range_mask_2 = zeros(size(curr_input_padded));
            avg_range_mask_2((along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) + 1 >= n_avg_ind + 1) & (along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) + 1 <= (2*n_avg_ind))) = 1;
            pad_slope_begin = ((sum(avg_range_mask_2.*curr_input_padded,1)./sum(avg_range_mask_2,1)) - (sum(avg_range_mask_1.*curr_input_padded,1)./sum(avg_range_mask_1,1)))/n_avg_ind;
            pad_val_begin = (sum(avg_range_mask_1.*curr_input_padded,1)./sum(avg_range_mask_1,1)) - (((n_avg_ind - 1)/2)*pad_slope_begin);
            avg_range_mask_1 = zeros(size(curr_input_padded));
            avg_range_mask_1((along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) - 1 <= -1) & (along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) - 1 >= -n_avg_ind)) = 1;
            avg_range_mask_2 = zeros(size(curr_input_padded));
            avg_range_mask_2((along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) - 1 <= -(n_avg_ind + 1)) & (along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) - 1 >= -(2*n_avg_ind))) = 1;
            pad_slope_end = (-(sum(avg_range_mask_2.*curr_input_padded,1)./sum(avg_range_mask_2,1)) + (sum(avg_range_mask_1.*curr_input_padded,1)./sum(avg_range_mask_1,1)))/n_avg_ind;
            pad_val_end = (sum(avg_range_mask_1.*curr_input_padded,1)./sum(avg_range_mask_1,1)) + (((n_avg_ind - 1)/2)*pad_slope_end);
            clear avg_range_mask_*
        end
    else
        if abs(uneven_edge_handling_opt) < 1e-5
            pad_slope_begin = curr_input_padded(floor(dim_length/2) + 1,:)/0.5;
            pad_val_begin = curr_input_padded(floor(dim_length/2) + 1,:);
            pad_slope_end = -curr_input_padded(floor(dim_length/2) + dim_length,:)/0.5;
            pad_val_end = curr_input_padded(floor(dim_length/2) + dim_length,:);
        else
            along_dim_ind_array = repmat((1:1:(2*dim_length))',[1 prod_size_not_inc_bp_dim]);
            avg_range_mask = zeros(size(curr_input_padded));
            avg_range_mask(abs(along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1])) < 1e-5) = 1;
            pad_slope_begin = (sum(avg_range_mask.*curr_input_padded,1)./sum(avg_range_mask,1))/0.5;
            pad_val_begin = sum(avg_range_mask.*curr_input_padded,1)./sum(avg_range_mask,1);
            avg_range_mask = zeros(size(curr_input_padded));
            avg_range_mask(abs(along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1])) < 1e-5) = 1;
            pad_slope_end = (sum(avg_range_mask.*curr_input_padded,1)./sum(avg_range_mask,1))/0.5;
            pad_val_end = sum(avg_range_mask.*curr_input_padded,1)./sum(avg_range_mask,1);
            clear avg_range_mask
        end
    end
    if abs(uneven_edge_handling_opt) < 1e-5
        curr_input_padded(padding_ind_begin,:) = repmat(pad_val_begin,[length(padding_ind_begin) 1]).*(1 + erf(((pi^(1/2))/2)*repmat(abs(pad_slope_begin./pad_val_begin),[length(padding_ind_begin) 1]).*(repmat(reshape(padding_ind_begin,[length(padding_ind_begin) 1]),[1 prod_size_not_inc_bp_dim]) - min(padding_ind_inside))));
        curr_input_padded(padding_ind_end,:) = repmat(pad_val_end,[length(padding_ind_end) 1]).*(1 - erf(((pi^(1/2))/2)*repmat(abs(pad_slope_end./pad_val_end),[length(padding_ind_end) 1]).*(repmat(reshape(padding_ind_end,[length(padding_ind_end) 1]),[1 prod_size_not_inc_bp_dim]) - max(padding_ind_inside))));
    else
        begin_padding_array = repmat(pad_val_begin,[(2*dim_length) 1]).*(1 + erf(((pi^(1/2))/2)*repmat(abs(pad_slope_begin./pad_val_begin),[(2*dim_length) 1]).*(along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]))));
        curr_input_padded(along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) < 0) = begin_padding_array(along_dim_ind_array - repmat(floor(dim_length/2) + first_good_ind,[(2*dim_length) 1]) < 0);
        end_padding_array = repmat(pad_val_end,[(2*dim_length) 1]).*(1 - erf(((pi^(1/2))/2)*repmat(abs(pad_slope_end./pad_val_end),[(2*dim_length) 1]).*(repmat((1:1:(2*dim_length))',[1 prod_size_not_inc_bp_dim]) - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]))));
        curr_input_padded(along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) > 0) = end_padding_array(along_dim_ind_array - repmat(floor(dim_length/2) + last_good_ind,[(2*dim_length) 1]) > 0);
        clear along_dim_ind_array
    end
    curr_input_padded((isnan(curr_input_padded) == 1) | (isinf(curr_input_padded) == 1)) = 0;


    curr_bandpass_gain_coeff_padded = ifft(repmat(bandpass_filter,[1 prod_size_not_inc_bp_dim]).*fft(curr_input_padded,[],1),[],1);
    bandpass_gain_coeff_permuted(:,:,curr_ind) = curr_bandpass_gain_coeff_padded(padding_ind_inside,:);
    
end

bandpass_gain_coeff_array = permute(reshape(bandpass_gain_coeff_permuted,[dim_length size_array([(1:1:(n_dim - 1)) ((n_dim + 1):1:length(size_array))]) dim_length]),[(2:1:n_dim) 1 ((n_dim + 1):1:length(size_array)) (length(size_array) + 1)]);
clear bandpass_gain_coeff_permuted
